<?php

	if (!function_exists('saatIni')){

		function saatIni(){
	        return date('Y-m-d H:i:s');
	    }   

	}